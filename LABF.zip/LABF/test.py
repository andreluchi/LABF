import pickle

# Function to load and print the contents of rules.bin
def check_rules_bin(file_path='bin/rules.bin'):
    try:
        with open(file_path, 'rb') as file:
            # Assuming you're storing multiple objects in the file
            while True:
                try:
                    # Load each object from the file and print it
                    content = pickle.load(file)
                    print(content)
                except EOFError:
                    # End of file reached
                    break
    except FileNotFoundError:
        print(f"No file found at {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Call the function to check the contents
check_rules_bin()
