from util.tokens import *
from util.stringFunctions import *
from Lexer.DFADirect import *
from Lexer.ExpressionTree import *
from Lexer.regEx import *
import pickle 

with open ("bin/rules.bin", "rb") as f:
    tokenRules = pickle.load(f)
    tokensExp = pickle.load(f)

lines = []
file = input("Enter input file number: ") 
file = "YALex/slr-" + file + ".yal.run"
with open(file, "r") as f:
    lines = f.readlines()
finds = findAllT(lines, tokensExp)
tokens = {}
for key, value in finds.items():
    tokens[key] = []
    for i in range(len(value)):
        if last(value[i]) == "U":
            tokens[key] += [(value[i][0], "TOKEN ERROR", value[i][1], value[i][2])]
            break
        for y in tokenRules.keys():
            if matches(value[i][0], y) and last(value[i]) == "I":
                tokens[key] += [(value[i][0], tokenRules[y], value[i][1], value[i][2])]

print("\n\ntokens found\n")
for key, value in tokens.items():
    print(f"--------------- {key} ---------------\n")
    for i in value:
        print(i[1], " from ", i[2], " to ", i[3], " -> ", i[0])

with open ('bin/parsing.bin', 'rb') as f:
    ignores = pickle.load(f)
    productions = pickle.load(f)
parseLines(tokens, productions)