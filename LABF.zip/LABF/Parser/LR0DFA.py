from collections import defaultdict
from graphviz import Digraph
import pickle
from prettytable import PrettyTable
class LR0DFA:
    def __init__(self, rules):
        with open ("bin/parsing.bin", "rb") as f:
            self.ignores = pickle.load(f)
            self.productions = pickle.load(f)
        self.start_symbol = "S'"
        self.rules = [(self.start_symbol, rules[0].split("->")[0])] + [tuple(rule.split("->")) for rule in rules]
        self.non_terminals = set(nt for nt, _ in self.rules)
        self.terminals = set(t for _, prod in self.rules for t in prod.split()) - self.non_terminals
        self.terminals.add('$')  # Step 1: Add a new terminal symbol $
        self.first_sets = None
        self.follow_sets = None
        self.states = None
        self.transitions = None
        self.action_table = None
        self.goto_table = None
        self.compute_first_sets()
        self.construct_lr0_dfa()
        self.construct_parsing_tables()

    def calcProds(self, non_terminal):
        return [prod for nt, prod in self.rules if nt == non_terminal]

    def closure(self, item_set):
        closure_set = set(item_set)
        while True:
            new_items = set()
            for nt, prod, dot_pos in closure_set:
                prod_symbols = prod.split()
                if dot_pos < len(prod_symbols):
                    next_symbol = prod_symbols[dot_pos]
                    if next_symbol in self.non_terminals:
                        for new_prod in self.calcProds(next_symbol):
                            new_items.add((next_symbol, new_prod, 0))
            if new_items.issubset(closure_set):
                break
            closure_set |= new_items
        return closure_set

    def goto(self, item_set, symbol):
        new_item_set = set()
        for nt, prod, dot_pos in item_set:
            prod_symbols = prod.split()
            if dot_pos < len(prod_symbols) and prod_symbols[dot_pos] == symbol:
                new_item_set.add((nt, prod, dot_pos + 1))
        return self.closure(new_item_set)

    def construct_lr0_dfa(self):
        initial_state = self.closure({(self.start_symbol, self.rules[1][0], 0)})
        states = [initial_state]
        transitions = defaultdict(dict)
        unprocessed = [initial_state]
        while unprocessed:
            state = unprocessed.pop()
            for symbol in self.terminals | self.non_terminals:
                next_state = self.goto(state, symbol)
                if next_state and next_state not in states:
                    states.append(next_state)
                    unprocessed.append(next_state)
                if next_state:
                    transitions[frozenset(state)][symbol] = frozenset(next_state)
            # Step 2: Identify accept state and add a $ transition to it
            for nt, prod, dot_pos in state:
                if nt == self.start_symbol and dot_pos == len(prod.split()):
                    #generate a new state just called ACCEPT
                    accept_state = {('ACCEPT', '', 0)}
                    if accept_state not in states:
                        states.append(accept_state)
                    transitions[frozenset(state)]['$'] = frozenset(accept_state)
        self.states = states
        self.transitions = transitions

    def draw_lr0_dfa(self):
        dot = Digraph(format='pdf', engine='dot')
        # Add nodes
        for i, state in enumerate(self.states):
            state_label = f"State {i}\n"
            if ('ACCEPT', '', 0) in state:
                state_label += "(ACCEPT)"
            else:
                for nt, prod, dot_pos in state:
                    prod_symbols = prod.split()
                    state_label += f"{nt} -> {' '.join(prod_symbols[:dot_pos])}.{' '.join(prod_symbols[dot_pos:])}\n"
            dot.node(str(i), label=state_label)

        # Add edges
        for state in self.states:
            for symbol, next_state in self.transitions[frozenset(state)].items():
                dot.edge(str(self.states.index(state)), str(self.states.index(next_state)), label=symbol)
        dot.render(f'Graphs/LR0', view=False)

    def compute_first_sets(self):
        self.first_sets = {nt: set() for nt in self.non_terminals}
        change = True
        while change:
            change = False
            for nt, prod in self.rules:
                first = prod.split()[0]
                if first in self.terminals:
                    if first not in self.first_sets[nt]:
                        self.first_sets[nt].add(first)
                        change = True
                elif first in self.non_terminals:
                    for f in self.first_sets[first]:
                        if f not in self.first_sets[nt]:
                            self.first_sets[nt].add(f)
                            change = True
        return self.first_sets

    def compute_follow_sets(self, start_symbol):
        follow_sets = {nt: set() for nt in self.non_terminals}
        follow_sets[start_symbol].add('$')
        change = True
        while change:
            change = False
            for nt, prod in self.rules:
                prod_symbols = prod.split()
                for i, symbol in enumerate(prod_symbols):
                    if symbol in self.non_terminals:
                        if i < len(prod_symbols) - 1:
                            next_symbol = prod_symbols[i + 1]
                            if next_symbol in self.terminals:
                                if next_symbol not in follow_sets[symbol]:
                                    follow_sets[symbol].add(next_symbol)
                                    change = True
                            elif next_symbol in self.non_terminals:
                                for f in self.first_sets[next_symbol]:
                                    if f not in follow_sets[symbol]:
                                        follow_sets[symbol].add(f)
                                        change = True
                        if i == len(prod_symbols) - 1 or (i < len(prod_symbols) - 1 and prod_symbols[i + 1] in self.non_terminals):
                            for f in follow_sets[nt]:
                                if f not in follow_sets[symbol]:
                                    follow_sets[symbol].add(f)
                                    change = True
        return follow_sets

    def construct_parsing_tables(self):
        action_table = defaultdict(dict)
        goto_table = defaultdict(dict)
        follow_sets = self.compute_follow_sets(self.rules[0][1])  # Using the start symbol from the original grammar
        for i, state in enumerate(self.states):
            for item in state:
                head, body, dot = item
                if dot != len(body.split()):
                    next_symbol = body.split()[dot]
                    if next_symbol in self.terminals:
                        next_state = self.transitions[frozenset(state)].get(next_symbol)
                        if next_state is not None:
                            action_table[i][next_symbol] = ('shift', self.states.index(next_state))
                    elif next_symbol in self.non_terminals:
                        next_state = self.transitions[frozenset(state)].get(next_symbol)
                        if next_state is not None:
                            goto_table[i][next_symbol] = self.states.index(next_state)
                elif head != self.start_symbol:
                    if head in self.non_terminals:  # Only compute follow sets for non-terminals
                        for symbol in follow_sets[head]:
                            action_table[i][symbol] = ('reduce', self.rules.index((head, body)))
                elif head == self.start_symbol and dot == len(body.split()):
                    action_table[i]['$'] = ('accept', None)
        self.action_table = action_table
        self.goto_table = goto_table

    def showTable(self):
        print('\nACTION Table:')
        terminals = sorted(self.terminals)
        non_terminals = sorted(self.non_terminals)
        table = PrettyTable()
        table.field_names = ['State'] + terminals
        for state, actions in self.action_table.items():
            row = [str(state)]
            for terminal in terminals:
                action = actions.get(terminal)
                if action:
                    row.append(f'{action[0]} {action[1]}')
                else:
                    row.append('')
            table.add_row(row)
        print(table)

        print('\nGOTO Table:')
        goto_table = PrettyTable()
        goto_table.field_names = ['State'] + non_terminals
        for state, gotos in self.goto_table.items():
            row = [str(state)]
            for non_terminal in non_terminals:
                goto_state = gotos.get(non_terminal)
                if goto_state is not None:
                    row.append(str(goto_state))
                else:
                    row.append('')
            goto_table.add_row(row)
        print(goto_table)

    def parse(self, tokens):
        stack = [0]  
        toktypes = []
        for token in tokens:
            if token[1] not in self.ignores:
                toktypes.append(token[1])
        toktypes.append('$')  
        i = 0
        while True:
            top = stack[-1]
            symbol = toktypes[i]
            if symbol in self.ignores:
                i += 1
                continue
            try:
                action, value = self.action_table[top][symbol]
            except KeyError:
                print("Parsing error: Invalid syntax at token:", symbol, "at token:", tokens[i][0], "position", tokens[i][2])
                return False
            if action == 'shift':
                stack.append(value)
                i += 1
            elif action == 'reduce':
                head, body = self.rules[value]
                stack = stack[:-len(body.split())]
                top = stack[-1]
                stack.append(self.goto_table[top][head])
            elif action == 'accept':
                return True
            else:
                return False
