from util.stringFunctions import *
from util.functions import *
from util.tokens import *
import pickle

class yaparProcessor:
    def __init__(self, file_path) :
        self.file_path = file_path
        self.lines = []
        self.comments = []
        self.rules = []
        self.productions = []
        self.ignores = ["N",]
        with open('bin/rules.bin', 'rb') as file:
            self.tokenRules = pickle.load(file)
            self.tokensExp = pickle.load(file)
        self.processYaPar()
        with open('bin/parsing.bin', 'wb') as file:
            pickle.dump(self.ignores, file)
            pickle.dump(self.productions, file)

    def processYaPar(self):
        self.getLines()
        self.getComments()
        self.getTokens()
        self.getProductions()
        self.genFiles()

    def getLines(self):
        #remove lines that are only \n
        with open(self.file_path, 'r') as file:
            for line in file:
                if line != '\n':
                    self.lines.append(line)

    def getComments(self):
        finds = findAll(self.lines, '/*(^a)∗*/')
        lastline = 0
        for key, value in finds.items():
            for i in range(len(value)):
                self.comments.append(value[i][0])
                lastline = key
        self.lines = self.lines[lastline:]

    def getTokens(self):
        index = 0
        errors = False
        separator = False
        for i in range(len(self.lines)):
            if matches(self.lines[i], '%%\n'):
                index = i
                separator = True
                break
        if not separator:
            raise Exception("No productions separator '%%' found")
        tokenlines = self.lines[:index]
        finds = findAll(tokenlines, '(A-Z)+')
        for key, value in finds.items():
            for i in range(len(value)):
                if startsWith(value[i][0], 'IGNORE'):
                    self.ignores.append(value[i+1][0])
                elif(value[i][0] in self.tokenRules.values()):
                    self.rules.append(value[i][0])
                else:
                    print("Error: ", value[i][0], " is not a valid token")
                    errors = True
        if errors:
            raise Exception("Invalid token(s) found")

    def getProductions(self):
        index = 0
        inProd = False
        production = ''
        prodHead = ''
        #Find the lines where productions start
        for i in range(len(self.lines)):
            if matches(self.lines[i], '%%\n'):
                index = i
                break
        productions = self.lines[index+1:]
        #process productions
        for x in productions:
            x = x.strip()
            #We find the head of the production
            if matches(x, '(a-z)+:') and not inProd:
                inProd = True
                x = x.replace(':', '->')
                production += x
                prodHead = x
            elif matches(x, '(a-z):') and inProd:
                raise Exception(f"Invalid production found {x} maybe you forgot a ';' ?")
            #if there is an or we keep the head but reset the prodction
            elif inProd and startsWith(x, "'|'"):
                self.productions.append(production)
                production = ''
                production += prodHead
                beginning = findIn(x, "(a-z)|(A-Z)")
                beginning = beginning[0][2]
                production += x[beginning:]
            elif matches(x, ';') and inProd:
                inProd = False
                self.productions.append(production)
                production = ''
                prodHead = ''
            elif matches(x, ';') and not inProd:
                raise Exception(f"Invalid production found {x}")
            elif inProd:
                production += x

    def genFiles(self):
        content = ""
        with open("scanner.py", "a") as f:
            content +="\
with open ('bin/parsing.bin', 'rb') as f:\n\
    ignores = pickle.load(f)\n\
    productions = pickle.load(f)\n\
\
parseLines(tokens, productions)"
            f.write(content)