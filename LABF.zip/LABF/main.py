from Lexer.yalex import *
from Parser.LR0DFA import *
from Parser.yapar import *

while True:
    slrOption = input("yal file?")
    filepath = f"YALex/slr-{slrOption}.yal"
    yalex = YalProcessor(filepath)


    slrOption = input("yalp file?")
    filepath = f"YALex/slr-{slrOption}.yalp"
    par = yaparProcessor(filepath)

    grammar = LR0DFA(par.productions)
    grammar.showTable()

    with open("scanner.py", "r") as f:
        exec(f.read())